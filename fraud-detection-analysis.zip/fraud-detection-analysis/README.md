# HEALTHCARE PROVIDER FRAUD DETECTION ANALYSIS

### Project Objectives

   - Provider Fraud is one of the biggest problems facing/faced in Medicare. According to the government, the total Medicare spending            increased exponentially due to frauds in Medicare claims. 
   - Healthcare fraud is an organized crime which involves peers of providers, physicians, beneficiaries acting together to make fraud claims.

   - Rigorous analysis of Medicare data has yielded many physicians who indulge in fraud. They adopt ways in which an ambiguous diagnosis code is used to adopt costliest procedures and drugs. 

   - Insurance companies are the most vulnerable institutions impacted due to these bad practices. Due to this reason, insurance companies increased their premiums and as result healthcare is becoming costly matter day by day.

### Recommended Solution

   - Our model seems to catch a lot of the fraudulent cases. The number of normal transactions classified as frauds is really high. Based on business decision ,one can set threshold to create a tradeoff between Fraud and Non Fraud class predictions.
   
   - Adding More data time to time and training will improve the performance of detection of new fraud patterns and help us to understand Providers fradulent behaviour.

**In this Project,we have used Supervised and Unsupervised machine learning(ML) algorithms to classify Fradulent behaviour of Healthcare providers.

For the purpose of classifying providers in Fraud and Non Fraud category we used following methods:-

1) **Feature Engineering**

   - Medicare fraud is categorised as organized crime which involves peers working together to create fraud transactions of claims.

   - Adding features from grouping them helped in improving accuracy of prediction and fraud pattern recognition.

   - Grouping and aggregating numeric features to provider level helped in detecting behaviour of their transactions overall.

2) **Logistic Regression Classifier**

   - Features derived from above step are trained using logistic regression and evaluated.

   - choosing the decision of LR is to check linear behaviour between dependent and independent variables.

   - Logistic model also adds explicability to the predictions.
   
![LRC ROC Curve Graph](https://github.optum.com/Ctrl-Alt-Elite/fraud-detection-analysis/blob/master/images/ROC_Curve_For_LRC.png)

![LRC Analysis](https://github.optum.com/Ctrl-Alt-Elite/fraud-detection-analysis/blob/master/images/LRC_Analysis.png)

3) **SVM**

   - Main reason to use an SVM is, the problem might not be linearly separable. In that case, we will have to use an SVM with a non-linear kernel (e.g. RBF).

   - Another related reason is to use SVMs, if you are in a highly dimensional space. For example, SVMs have been reported to work better for such text classification.

![SVM ROC Curve Graph](https://github.optum.com/Ctrl-Alt-Elite/fraud-detection-analysis/blob/master/images/ROC_Curve_For_SVM.png)

![SVM Analysis](https://github.optum.com/Ctrl-Alt-Elite/fraud-detection-analysis/blob/master/images/SVM_Analysis.png)

4) **KNN**

   - It is one of the robust method, to noisy training data and is effective in case of large number of training examples.

   - For this algorithm, we have to determine the value of parameter K (number of nearest neighbors) and the type of distance to be used.

   - The computation time is also very much as we need to compute distance of each query instance to all training samples.
   
![KNN ROC Curve Graph](https://github.optum.com/Ctrl-Alt-Elite/fraud-detection-analysis/blob/master/images/ROC_Curve_For_KNN.png)

![KNN Analysis](https://github.optum.com/Ctrl-Alt-Elite/fraud-detection-analysis/blob/master/images/KNN_Analysis.png)

5) **Random Forest Classifier**

   - One of benefits of Random forest which excites most is, the power of handle large data set with higher dimensionality. 

   - It can handle thousands of input variables and identify most significant variables.

   - Further, the model outputs Importance of variable, which can be a very handy feature.

   - It also checks for non linearity between variables.
   
![RFC ROC Curve Graph](https://github.optum.com/Ctrl-Alt-Elite/fraud-detection-analysis/blob/master/images/ROC_Curve_for_RFC.png)

![RFC Analysis](https://github.optum.com/Ctrl-Alt-Elite/fraud-detection-analysis/blob/master/images/RFC_Analysis.png)

### Conclusion

Important Features In this Project,we studied behaviour of Providers and found following important features impactful in predicting Fraud/NonFraud are folowing:

   - PerProviderAvg_InscClaimAmtReimbursed( Importance: 8%)
   - InscClaimAmtReimbursed (Importance: 7%)
   - PerAttendingPhysicianAvg_InscClaimAmtReimbursed (Importance: 7%)
   - PerOperatingPhysicianAvg_InscClaimAmtReimbursed (Importance: 6%)
   - PerClmAdmitDiagnosisCodeAvg_InscClaimAmtReimbursed (Importance: 4%)

Model Performance is purely based on business requirement,threshold can be set on prediction probabilities.

This threshold can be varied for different performance of these models.

Recall and Precision tradeoff is entirely based on business decision.

By observing all the models, Our models consistentently performed with **~0.90 Accuracy, ~0.80 AUROC score and ~0.55 Kappa Score**.

### Improvements

1). Model

   - Adding more fraud data to the training dataset help in predicting unseen fraudulent behaviour time to time.

   - Ensembling methods with parameter tuning can improve performance of the models.

   - Vectorizing Medical codes(ICD 9 codes) with Count Vectoriser may add performance imporvement.

2). Business Recommendation

   - Above models will help in predicting Provider fraud ,which will be helpful for insurance companies to scrutinize claims thoroughly.
   
   - Improvement in the model will help in detecting networks of fraud Physicians,Providers and Beneficiaries.

   - This type of project will help in improving health of economy by reducing inflation caused by fraud peers and lowering down insurance premiums which will certainly not cause health to become costly affair.

